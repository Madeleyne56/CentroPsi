##   Calendario de Eventos con PHP y MYSQL

###### FullCalendar es una herramienta ideal para proyectos de gestión de eventos. Con su interfaz intuitiva y amigable, podrás crear un calendario en el que puedas agendar, editar y eliminar eventos de manera sencilla. Con FullCalendar, podrás personalizar fácilmente el diseño y la funcionalidad del calendario para que se ajuste a las necesidades específicas de tu proyecto. ¡Intégralo en tu proyecto y haz la gestión de eventos una tarea fácil y agradable!

![](https://raw.githubusercontent.com/urian121/imagenes-proyectos-github/master/calendario_con_full_calendar_urain_viera_webdeveloper.PNG)


###### Por Ing. Urian Viera

