document.querySelectorAll('.accordion-header').forEach(button => {
    button.addEventListener('click', () => {
        const accordionContent = button.nextElementSibling;

        document.querySelectorAll('.accordion-content').forEach(content => {
            if (content !== accordionContent) {
                content.style.display = 'none'; // Cerrar cualquier otro contenido abierto
            }
        });

        if (accordionContent.style.display === 'block') {
            accordionContent.style.display = 'none'; // Cerrar el actual si está abierto
        } else {
            accordionContent.style.display = 'block'; // Mostrar el actual si está cerrado
        }
    });
});
